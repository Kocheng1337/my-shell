<div class='btn-blocks row'>
<?php
	echo "<div class='col-xs-12'><h3 class='mt0'>SFS Settings</h3></div>
		<div class='col-xs-12 col-sm-6 col-md-4'>
			<a href='?as=$adminSection&amp;ass=timezone' class='btn btn-default btn-block btn-lg'>Timezone Settings<br /><i class='fa fa-clock-o fa-3x'></i></a>
		</div>
		<div class='col-xs-12 col-sm-6 col-md-4'>
			<a href='?as=$adminSection&amp;ass=download' class='btn btn-default btn-block btn-lg'>Download Settings<br /><i class='fa fa-download fa-3x'></i></a>
		</div>
		<div class='col-xs-12 col-sm-6 col-md-4'>
			<a href='?as=$adminSection&amp;ass=upload' class='btn btn-default btn-block btn-lg'>Upload Settings<br /><i class='fa fa-upload fa-3x'></i></a>
		</div>
		<div class='col-xs-12 col-sm-6 col-md-4'>
			<a href='?as=$adminSection&amp;ass=mail' class='btn btn-default btn-block btn-lg'>Mail Settings<br /><i class='fa fa-envelope fa-3x'></i></a>
		</div>
		<div class='col-xs-12 col-sm-6 col-md-4'>
			<a href='?as=$adminSection&amp;ass=shorturls' class='btn btn-default btn-block btn-lg'>Short Urls<br /><i class='fa fa-link fa-3x'></i></a>
		</div>
		<div class='col-xs-12 col-sm-6 col-md-4'>
			<a href='?as=$adminSection&amp;ass=error_log' class='btn btn-default btn-block btn-lg'>SFS Error Log<br /><i class='fa fa-bars fa-3x'></i></a>
		</div>";
	?>


</div>