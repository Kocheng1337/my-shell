if you add another language you have to increase the array in the config.php (language switcher)
