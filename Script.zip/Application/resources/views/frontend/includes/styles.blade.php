<link rel="stylesheet" href="{{ asset('assets/vendor/libs/bootstrap/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/fontawesome/fontawesome.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/toastr/toastr.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/extra/colors.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/extra/extra.css') }}">
@stack('styles_libs')
<link rel="stylesheet" href="{{ asset(mix('assets/css/application.css')) }}">
@stack('styles')
<link rel="stylesheet" href="{{ asset('assets/css/extra/custom.css') }}">
