<div class="share">
    <a href="https://www.facebook.com/sharer/sharer.php?u={{ url()->current() }}" class="social-btn social-facebook"
        target="_blank">
        <i class="fab fa-facebook-f"></i>
    </a>
    <a href="https://twitter.com/intent/tweet?text={{ url()->current() }}" class="social-btn social-twitter"
        target="_blank">
        <i class="fab fa-twitter"></i>
    </a>
    <a href="https://www.linkedin.com/shareArticle?mini=true&url={{ url()->current() }}"
        class="social-btn social-linkedin" target="_blank">
        <i class="fab fa-linkedin"></i>
    </a>
    <a href="https://wa.me/?text={{ url()->current() }}" class="social-btn social-whatsapp" target="_blank">
        <i class="fab fa-whatsapp"></i>
    </a>
    <a href="http://pinterest.com/pin/create/button/?url={{ url()->current() }}" class="social-btn social-pinterest"
        target="_blank">
        <i class="fab fa-pinterest"></i>
    </a>
</div>
