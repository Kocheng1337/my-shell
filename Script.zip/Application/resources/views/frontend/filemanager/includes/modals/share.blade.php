<div id="filemanager-share-modal" class="modal fade" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="filemanager-share-modal-body" class="modal-body p-4 pt-1 mb-1"></div>
        </div>
    </div>
</div>
