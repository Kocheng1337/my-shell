@include('frontend.global.includes.head')
@push('styles_libs')
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/vironeer/vironeer-icons.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.min.css') }}">
@endpush
@include('frontend.global.includes.styles')
