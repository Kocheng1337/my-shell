 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/bootstrap/bootstrap.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/fontawesome/fontawesome.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/simplebar/simplebar.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatable/datatables.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/sweetalert/sweetalert2.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/animate.css/animate.min.css') }}">
 @stack('styles_libs')
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/toggle-master/bootstrap-toggle.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/toastr/toastr.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/select2/select2.min.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/libs/select2/select2-bootstrap-5-theme.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/css/extra/colors.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/vendor/admin/css/application.css') }}">
 @stack('styles')
