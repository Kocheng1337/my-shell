@extends('errors.layout')
@section('title', lang('Too Many Requests', 'error pages'))
@section('code', '429')
@section('message', lang('Too Many Requests', 'error pages'))
